"""import pygame
class Ship():
    def __init__(self,ai_settings,screen):
        self.screen=screen
        self.ai_settings=ai_settings
        self.image=pygame.image.load('images/ship.bmp')
        self.rect=self.image.get_rect()
        self.screen_rect=screen.get_rect()
        self.rect.centerx=self.screen_rect.centerx
        self.rect.bottom = self.screen_rect.bottom
        self.center=float(self.rect.centerx)
        self.moving_right=False
        self.moving_left = False
    def update(self):
        if self.moving_right and self.rect.right<self.screen_rect.right:
            self.center+=self.ai_settings.ship_speed_factor
        if self.moving_left and self.rect.left>0:
            self.center-=self.ai_settings.ship_speed_factor
        self.rect.centerx=self.center
    def blitme(self):
        self.screen.blit(self.image,self.rect)"""
import pygame
from pygame.sprite import Sprite

class Ship(Sprite):


  def __init__(self,ai_settings,screen):
#初始化飛船，並設置其初始位置
    super(Ship,self).__init__()
    self.screen=screen
    self.ai_settings = ai_settings

#加載飛船圖像，並獲取其外界矩形
    self.image = pygame.image.load(self.ai_settings.ship_image_path)
    self.image = pygame.transform.smoothscale(self.image,(40,60))
    self.rect = self.image.get_rect()
    self.screen_rect = screen.get_rect()

#將每艘新飛船放在屏幕底部中央
    self.rect.centerx = self.screen_rect.centerx
    self.rect.bottom = self.screen_rect.bottom

    self.center = float(self.rect.centerx)
#飛船的屬性center中儲存小數值

    self.moving_right = False
    self.moving_left = False

  def blitme(self):
#在指定位置繪製飛船
    self.screen.blit(self.image,self.rect)

  def update(self):#根據移動標志調整飛船位置
#更新飛船的center值而不是rect
    if self.moving_right and self.rect.right < self.screen_rect.right:#上一行移動標志
      self.center +=self.ai_settings.ship_speed_factor

    if self.moving_left and self.rect.left > self.screen_rect.left:
      self.center -= self.ai_settings.ship_speed_factor
#根據self.center更新rect對象
    self.rect.centerx = self.center

  def center_ship(self):

    self.center = self.screen_rect.centerx
